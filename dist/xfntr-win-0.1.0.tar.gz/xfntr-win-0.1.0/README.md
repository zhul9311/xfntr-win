A GUI software to process, analyze and visualize XFNTR data
